from __future__ import annotations

import logging
import math
from typing import TYPE_CHECKING, Any, cast

from py_aep.enums import AutoOrientType, Label, LayerType

from ...ae_version import ae_writes
from ...binary.chunk import ListChunk
from ...binary.composition_chunks import layer_timebase, rescale_ticks
from ...binary.item_chunks import CmtaChunk
from ...binary.mutations import (
    build_gide_list,
    build_ovdg,
    clone_chunk_tree,
    remap_layer_ref_tdpi,
    rewrite_owner_tdpi,
    rewrite_time_base,
)
from ...binary.property_chunks import TdmnChunk, TdsbChunk, TdsnChunk
from ...binary.scalar_chunks import Utf8Chunk
from ...binary.utils import (
    filter_by_list_type,
    filter_by_type,
    find_by_type,
    index_by_identity,
)
from ...parsers.effect import _effect_instances, rehome_effect_definitions
from ...parsers.property import parse_properties
from ...parsers.utils import get_chunks_by_match_name, get_match_name_runs
from ...resolvers.transform import (
    Mat4,
    aspect_scale,
    build_world_matrix,
    compose_orientation,
    decompose_transform,
    layer_source_aspect,
    position_space_aspect,
    rig_aims_at_poi,
    rotation_part,
    square_pixels,
    strip_orientation,
)
from ..descriptors import ChunkField, _suppress_materialization
from ..naming import auto_name
from ..properties.property import Property
from ..properties.property_base import PropertyBase
from ..properties.property_group import PropertyGroup
from ..validators import (
    _validate_number,
    validate_int,
    validate_number,
    validate_string,
)

if TYPE_CHECKING:
    from ...binary.layer_chunks import LdtaChunk
    from ..items.av_item import AVItem
    from ..items.composition import CompItem
    from ..properties.keyframe import Keyframe
    from ..properties.marker import MarkerValue


logger = logging.getLogger(__name__)

# AE turns any stretch under 1 % into 655 / 65536 (1 % in 16.16, rounded
# down), in percent.
_MIN_STRETCH = 655 * 100 / 65536

# The stretch is a float32 stored as a ratio with a signed 32-bit dividend;
# 2147483520 is the largest float32 under 2**31.
_validate_stretch = _validate_number(min=-2147483520 * 100.0, max=2147483520 * 100.0)

# The start time is a signed 32-bit count of the layer's timebase ticks.
_validate_start_time = _validate_number(
    min=lambda layer: -0x80000000 / layer._layer_timebase(),
    max=lambda layer: 0x7FFFFFFF / layer._layer_timebase(),
)

#: Sentinel value indicating an undefined source id in the binary format.
_UNDEFINED_ID = 0xFFFFFFFF


def _no_source_id(comp: CompItem) -> int:
    """The ldta source id of a light without a source: 0 before AE 23, which
    writes the undefined id."""
    major = comp._project._head.ae_version_major
    return _UNDEFINED_ID if ae_writes("light source id", major) else 0


def _parse_ovg2_uuids(tdgp_chunks: list[Any]) -> list[str]:
    """Extract Essential Properties override UUIDs from LIST:OvG2 chunks.

    Args:
        tdgp_chunks: The children of the layer's root `tdgp` group, where
            `LIST:OvG2` is a direct child (beside the "ADBE Layer Overrides"
            marker). NOT the layer LIST's own children - `OvG2` sits one
            level deeper than that.

    Returns:
        A list of controller UUID strings from the OvG2/CPrp/Utf8 entries;
        each matches an `EssentialGraphicsController.uuid` on the source comp.
    """
    uuids: list[str] = []
    for ovg2_list in filter_by_list_type(chunks=tdgp_chunks, list_type="OvG2"):
        for cprp in filter_by_list_type(chunks=ovg2_list.chunks, list_type="CPrp"):
            utf8_chunks = filter_by_type(chunks=cprp.chunks, chunk_type="Utf8")
            if utf8_chunks:
                uuids.append(cast("Utf8Chunk", utf8_chunks[0]).value)
    return uuids


def _parent_world(parent: Layer | None, time: float, child_is_3d: bool) -> Mat4:
    """World matrix a child of `parent` is placed in, at comp `time`."""
    if parent is None:
        return Mat4.identity()
    return build_world_matrix(parent, time, flatten_2d=not child_is_3d, as_parent=True)


class Layer(PropertyGroup):
    """
    The `Layer` object provides access to layers within compositions.

    Info:
        `Layer` is a subclass of [PropertyGroup][], which is a subclass of
        [PropertyBase][py_aep.models.properties.property_base.PropertyBase]. All
        methods and attributes of [PropertyGroup][], in addition to those listed below,
        are available when working with `Layer` objects.

    Info:
        `Layer` is the base class for [CameraLayer][] object, [LightLayer][]
        object and [AVLayer][] object, so `Layer` attributes and methods are
        available when working with all layer types.

    See: https://ae-scripting.docsforadobe.dev/layer/layer/
    """

    _LAYER_MATCH_NAMES: dict[LayerType, str] = {
        LayerType.AV: "ADBE AV Layer",
        LayerType.LIGHT: "ADBE Light Layer",
        LayerType.CAMERA: "ADBE Camera Layer",
        LayerType.TEXT: "ADBE Text Layer",
        LayerType.SHAPE: "ADBE Vector Layer",
        LayerType.THREE_D_MODEL: "ADBE 3D Model Layer",
        LayerType.PARAMETRIC_MESH: "ADBE3D ParametricMeshLayer",
    }

    _LAYER_TYPE_NAMES: dict[LayerType, str] = {
        LayerType.AV: "AVLayer",
        LayerType.LIGHT: "LightLayer",
        LayerType.CAMERA: "CameraLayer",
        LayerType.TEXT: "Layer",
        LayerType.SHAPE: "Layer",
        LayerType.THREE_D_MODEL: "Layer",
        LayerType.PARAMETRIC_MESH: "ParametricMeshLayer",
    }

    # The (group, property) match names whose default follows other state,
    # which `_write_out_moved_defaults` writes once that state moves it.
    _LIVE_DEFAULTS: tuple[tuple[str, str], ...] = (
        ("ADBE Transform Group", "ADBE Position"),
    )

    def _comp_centre(self) -> list[float]:
        comp = self.containing_comp
        return [comp.width / 2.0, comp.height / 2.0, 0.0]

    def _default_position(self) -> list[float]:
        """AE's default Position: the comp centre. A left-out Position stays
        where it was when the comp is resized, and AE writes it: measured on
        AE 2026 for a solid, a text, a shape and a null layer."""
        return self._comp_centre()

    enabled = ChunkField.bool(
        "_ldta",
        "enabled",
    )
    """When `True`, the layer is enabled. Overrides `PropertyBase.enabled`
    to read from the ldta chunk. Read / Write."""

    id = ChunkField[int]("_ldta", "layer_id", read_only=True)
    """Unique and persistent identification number used internally to
    identify a Layer between sessions. Read-only."""

    label = ChunkField.enum(Label, "_ldta", "label")
    """The label color. Colors are represented by their number (0 for None,
    or 1 to 16 for one of the preset colors in the Labels preferences).
    Read / Write."""

    locked = ChunkField.bool(
        "_ldta",
        "locked",
    )
    """When `True`, the layer is locked. This corresponds to the lock toggle
    in the Layer panel. Read / Write."""

    null_layer = ChunkField[bool]("_ldta", "null_layer", read_only=True)
    """When `True`, the layer was created as a null object. Read-only."""

    _parent_id = ChunkField[int]("_ldta", "parent_id")
    """The ID of the layer's parent layer. `0` if the layer has no parent."""

    shy = ChunkField.bool(
        "_ldta",
        "shy",
    )
    """When `True`, the layer is "shy", meaning that it is hidden in the
    Layer panel if the composition's "Hide all shy layers" option is
    toggled on. Read / Write."""

    solo = ChunkField.bool(
        "_ldta",
        "solo",
    )
    """When `True`, the layer is soloed. Read / Write."""

    @property
    def start_time(self) -> float:
        """The start time of the layer, expressed in composition time
        (seconds). Read / Write.

        Writing snaps the time to the nearest tick of the layer's own
        timebase (see [stretch][]), a tie rounding up, as After Effects does:
        on AE 2026, 1.3 s on a 24 fps layer reads back as 1.3000081 s
        (31949 / 24576) and on a 150 % one as 1.2999946 s (47923 / 36864).
        A later stretch change leaves the stored start alone.
        """
        return self._ldta.start_time

    @start_time.setter
    def start_time(self, value: float) -> None:
        _validate_start_time(value, self)
        timebase = self._layer_timebase()
        ldta = self._ldta
        ldta.start_time_dividend = math.floor(value * timebase + 0.5)
        ldta.start_time_divisor = timebase

    _stretch = ChunkField[float]("_ldta", "stretch")

    @property
    def stretch(self) -> float:
        """The layer's time stretch, expressed as a percentage. A value of 100
        means no stretch. Values between 0 and 1 are set to 1, and values
        between -1 and 0 (not including 0) are set to -1. Read / Write.

        Writing also rescales every keyframe on the layer. A layer counts its
        keyframe ticks against its own timebase,
        `comp internal_timebase * max(1, |stretch| / 100)` (at most 115200
        ticks a second), so stretching it
        while leaving the counts alone would halve or double each keyframe's
        position in LAYER time. After Effects keeps them fixed there and
        rescales the counts (measured on AE 2026: a key at layer-second 1 on
        a 24 fps comp holds 24576 ticks, and 49152 after the layer is
        stretched to 200 %, where its composition time becomes 2 s).

        The stretch is stored as AE writes it, a float32 of the percentage
        / 100: 133.33 reads back as 133.32999944686890. A value under 1
        (0 included) becomes the smallest stretch AE stores, 655 / 65536,
        which reads back as 0.99945068359375 (with the sign of a negative
        value), as on AE 2026. AE refuses more than 9900 % from a script
        but opens a file holding 1000000 %; py_aep accepts any stretch the
        file's signed 32-bit ratio can hold.
        """
        return cast("float", self._ldta.stretch)

    @stretch.setter
    def stretch(self, value: float) -> None:
        _validate_stretch(value, self)
        if abs(value) < 1.0:
            value = -_MIN_STRETCH if value < 0 else _MIN_STRETCH
        old = self._layer_timebase()
        self._stretch = value
        self._retime_to_layer_timebase(old, self._layer_timebase())

    def _layer_timebase(self, internal_timebase: int | None = None) -> int:
        """Keyframe units per second of this layer's own time, in its
        composition or one of `internal_timebase`."""
        if internal_timebase is None:
            internal_timebase = self.containing_comp._cdta.internal_timebase
        return layer_timebase(internal_timebase, self._stretch_factor)

    def _retime_to_layer_timebase(self, old: int, new: int) -> None:
        """Hold every keyframe at the same LAYER time across a stretch change
        (`rescale_ticks`)."""
        if new == old or old <= 0:
            return
        for prop in self._leaf_properties():
            if prop._is_live():
                prop._ensure_time_base()
            for keyframe in prop.keyframes:
                item = keyframe._ldat_item
                item.time_units = rescale_ticks(item.time_units, old, new)

    auto_orient = ChunkField.enum(
        AutoOrientType,
        "_ldta",
        "auto_orient",
    )
    """The type of automatic orientation to perform for the layer.
    Read / Write."""

    # Use identity-based equality to avoid comparing all fields recursively,
    # which could produce unexpected results or hit circular references.
    __eq__ = object.__eq__
    __hash__ = object.__hash__

    def __setattr__(self, name: str, value: Any) -> None:
        # Layers set public instance attributes of their own, which
        # `PropertyGroup.__setattr__` would refuse.
        object.__setattr__(self, name, value)

    def __init__(
        self,
        *,
        _ldta: LdtaChunk,
        _cmta: CmtaChunk | None,
        _name_utf8: Utf8Chunk,
        _layer_list: ListChunk,
        containing_comp: CompItem,
    ) -> None:
        self._ldta = _ldta
        self._cmta = _cmta
        self._layer_list = _layer_list
        # Read from the root tdgp on first access.
        self._essential_property_uuids: list[str] | None = None

        try:
            layer_type_raw = _ldta.layer_type
            layer_type = LayerType(layer_type_raw)
            match_name = self._LAYER_MATCH_NAMES[layer_type]
        except (ValueError, KeyError):
            logger.warning(
                "Unknown layer type %d for layer '%s' in comp '%s'. Defaulting to 'ADBE AV Layer'.",
                layer_type_raw,
                _name_utf8.value,
                containing_comp.name,
            )
            match_name = "ADBE AV Layer"

        super().__init__(
            _tdsb=None,
            _name_utf8=_name_utf8,
            match_name=match_name,
            auto_name="",
            property_depth=0,
            properties=[],
        )

        self._containing_comp = containing_comp

    @classmethod
    def _new(  # type: ignore[override]
        cls,
        *,
        ldta: LdtaChunk,
        name: str,
        containing_comp: CompItem,
        root_tdgp_extra: list[Any] | None = None,
        effect_param_defs: dict[str, dict[str, dict[str, Any]]] | None = None,
    ) -> Layer:
        validate_string(name)

        name_utf8 = Utf8Chunk(value=name)
        tdgp_chunks: list[Any] = [
            TdsbChunk(),
            TdsnChunk.new(),
        ]
        if root_tdgp_extra:
            tdgp_chunks.extend(root_tdgp_extra)
        # AE terminates every tdgp match-name stream with ADBE Group End
        # and rejects layers whose root tdgp lacks it ("missing data in
        # file"). Synthesized children are inserted before this marker.
        tdgp_chunks.append(TdmnChunk(value="ADBE Group End"))
        root_tdgp = ListChunk(list_type="tdgp", chunks=tdgp_chunks)
        ae_major = containing_comp._project._head.ae_version_major
        # The ldta matte-layer field (164- instead of 160-byte records).
        ldta.matte_layer_id = 0 if ae_writes("matte layer id", ae_major) else None
        gide, _lhd3, _inner = build_gide_list()
        layer_list = ListChunk(
            list_type="Layr",
            chunks=[ldta, name_utf8, root_tdgp, gide],
        )
        if ae_writes("layer OvdG", ae_major):
            layer_list.chunks.append(build_ovdg())

        layer = cls(
            _ldta=ldta,
            _cmta=None,
            _name_utf8=name_utf8,
            _layer_list=layer_list,
            containing_comp=containing_comp,
        )
        layer._tdgp = root_tdgp
        layer._build_property_tree(effect_param_defs or {})
        return layer

    # The effect definitions a parsed layer's property tree is built with on
    # first access, or `None` once it is built: opening a composition's
    # layers then only decodes their `ldta`, and a reader of layer
    # attributes alone (times, names, sources) never pays for the
    # properties. Until then `_properties` is absent from the instance, so
    # its first read lands in `__getattr__`; after that it is a plain
    # attribute, with nothing to check on each access.
    _tree_param_defs: dict[str, dict[str, dict[str, Any]]] | None = None

    def __getattr__(self, name: str) -> Any:
        # A public name may be a child looked up by attribute: build first.
        if self._tree_param_defs is not None and (
            name == "_properties" or not name.startswith("_")
        ):
            self._load_property_tree()
            return getattr(self, name)
        return super().__getattr__(name)

    @_suppress_materialization()
    def _load_property_tree(self) -> None:
        """Build the property tree of a parsed layer, if not built yet."""
        effect_param_defs = self._tree_param_defs
        if effect_param_defs is None:
            return
        # Cleared first, with an empty tree in place as during an eager
        # parse: parsing and synthesis read the layer's own properties.
        self._tree_param_defs = None
        self._properties = []
        try:
            self._build_property_tree(effect_param_defs)
        except BaseException:
            # Unbuilt again, so the next read raises too rather than seeing
            # a partial tree.
            del self._properties
            self._tree_param_defs = effect_param_defs
            raise

    def _build_property_tree(
        self, effect_param_defs: dict[str, dict[str, dict[str, Any]]]
    ) -> None:
        """Parse the root tdgp into this layer's properties and synthesize
        the ones the file leaves out."""
        from ...synthesis.core import synthesize_layer_properties  # noqa: PLC0415

        assert self._tdgp is not None
        props = parse_properties(
            match_name_runs=get_match_name_runs(self._tdgp),
            child_depth=1,
            effect_param_defs=effect_param_defs,
            composition=self.containing_comp,
            layer=self,
        )
        self._properties = props
        for child in props:
            child._parent_property = self
        synthesize_layer_properties(self)

    @property
    def essential_property_uuids(self) -> list[str]:
        """UUIDs of Essential Properties overrides on this layer.

        Each UUID corresponds to an [EssentialGraphicsController][] in
        the source composition's Essential Graphics panel.
        """
        if self._essential_property_uuids is None:
            assert self._tdgp is not None
            self._essential_property_uuids = _parse_ovg2_uuids(self._tdgp.chunks)
        return self._essential_property_uuids

    def __repr__(self) -> str:
        return (
            f"{type(self).__name__}("
            f"enabled={self.enabled!r}, "
            f"match_name={self.match_name!r}, "
            f"name={self.name!r})"
        )

    @PropertyBase.name.setter  # type: ignore[attr-defined]
    def name(self, value: str) -> None:
        PropertyBase.name.fset(self, value)  # type: ignore[attr-defined]
        self._ldta.layer_name = value
        # AE sets _layer_flags_0 bit 0 only for a SOURCE-BACKED layer whose name
        # differs from the source item's name. It stays 0 for sourceless layers
        # (camera/light/text/shape) even when named, for an empty (source-
        # inherited) name, and when the name is set back to the source item's
        # own name (verified against the MyGroup precomp layer in
        # grouped_layers_comp.aep, where name == source comp name -> bit 0).
        # Parametric mesh layers are the exception among sourceless layers:
        # renaming one in AE 2026 sets the bit, and it STAYS set even when
        # renamed back to the original default name (headless rename
        # experiment on parametric_meshes.aep), matching addParametricMesh's
        # explicit-name behavior.
        source_id = self._ldta.source_id
        if self._ldta.layer_type == LayerType.PARAMETRIC_MESH:
            self._ldta.name_set = True
        elif not value or source_id == 0:
            self._ldta.name_set = False
        else:
            source_item = self.containing_comp._project.items.get(source_id)
            self._ldta.name_set = getattr(source_item, "name", None) != value

    @property
    def comment(self) -> str:
        """A descriptive comment for the layer. Read / Write."""
        # AE 2026 shows no comment for a `cmta` whose ldta flag is unset.
        if self._cmta is None or not self._ldta.has_comment:
            return ""
        return self._cmta.value

    @comment.setter
    def comment(self, value: str) -> None:
        validate_string(value)
        if not value:
            # AE drops the chunk and the flag rather than store "".
            if self._cmta is not None:
                chunks = self._layer_list.chunks
                del chunks[index_by_identity(chunks, self._cmta)]
                self._cmta = None
            self._ldta.has_comment = False
            return
        self._ldta.has_comment = True
        if self._cmta is not None:
            self._cmta.value = value
        else:
            chunk = CmtaChunk()
            chunk.value = value
            chunks = self._layer_list.chunks
            # AE 15 writes the comment before the LIST:OvdG closing a layer.
            ends_with_ovdg = getattr(chunks[-1], "list_type", None) == "OvdG"
            chunks.insert(len(chunks) - 1 if ends_with_ovdg else len(chunks), chunk)
            self._cmta = chunk

    @property
    def containing_comp(self) -> CompItem:
        """The composition that contains this layer. Read-only."""
        return self._containing_comp

    @property
    def layer_type(self) -> str:
        """The type of layer. Matches ExtendScript `layerType` values:
        `"AVLayer"`, `"LightLayer"`, `"CameraLayer"`,
        `"ParametricMeshLayer"`, or `"Layer"`. Read-only."""
        return self._LAYER_TYPE_NAMES.get(LayerType(self._ldta.layer_type), "AVLayer")

    @property
    def time(self) -> float:
        """The current time of the layer, expressed in composition time
        (seconds). Read-only."""
        return self._containing_comp.time

    @property
    def frame_time(self) -> int:
        """The current time of the layer, expressed in composition time
        (frames). Read-only."""
        return self._containing_comp.frame_time

    @property
    def is_3d(self) -> bool:
        """Whether the layer transforms in three dimensions.

        `False` on the base [Layer][]: only an [AVLayer][] carries the
        3D switch, and cameras and lights are always 3D, so both override
        this. Read-only.
        """
        return False

    @property
    def _source_item(self) -> AVItem | None:
        """The layer's source item: none for a camera or a light (see
        `AVLayer.source`). For code handling any kind of layer, where
        `getattr(layer, "source", None)` would search the layer's properties
        for a child of that name."""
        return None

    @property
    def _pixel_size(self) -> tuple[float, float] | None:
        """The layer's pixel dimensions, for denormalizing effect points.

        `None` on the base [Layer][]: `width` / `height` live on
        [AVLayer][], and a camera or light has neither, so nothing
        normalized against a layer sits on one.
        """
        return None

    @property
    def _effect_point_size(self) -> tuple[float, float] | None:
        """The size the layer's effect points are stored normalized against.

        The layer's pixel size, except on an adjustment layer, whose effects
        render in its composition: AE 2026 stores a Transform anchor set to
        [30, 40] on a 200x100 adjustment solid in a 1920x1080 comp as
        30 / 1920, 40 / 1080, and defaults it to the comp's centre (as AE
        15.1 does).
        """
        if self.adjustment_layer:
            comp = self.containing_comp
            return float(comp.width), float(comp.height)
        return self._pixel_size

    @property
    def _stretch_factor(self) -> float:
        stretch = self.stretch
        return stretch / 100.0 if stretch != 0.0 else 1.0

    @property
    def _time_origin(self) -> float:
        """Composition time of the layer's own time 0.

        The start time, except on a time-reversed layer, which After
        Effects places `|stretch| / 100 / 3000` s earlier: its in point,
        out point and keyframes all move by that much (measured on AE
        2026 at -50 / -100 / -150 / -200 % on solid, null, text and
        precomp layers, starts 1.3 and -0.7 s, and 24 / 25 / 30 fps).
        """
        factor = self._stretch_factor
        if factor >= 0:
            return self.start_time
        return self.start_time + factor / 3000.0

    @property
    def in_point(self) -> float:
        """The "in" point of the layer, expressed in composition time
        (seconds). Read / Write.

        On a time-reversed layer the in point is the later end, and sits
        `|stretch| / 100 / 3000` s before the start time (1.2995 s for a
        -150 % layer starting at 1.3 s), as After Effects reports it.
        """
        return self._time_origin + self._ldta.in_point * self._stretch_factor

    @in_point.setter
    def in_point(self, value: float) -> None:
        validate_number(value)
        self._set_raw_in_point(value)

    @property
    def out_point(self) -> float:
        """The "out" point of the layer, expressed in composition time
        (seconds). Read / Write.

        On a time-reversed layer the out point is the earlier end (see
        [in_point][]).
        """
        return self._time_origin + self._ldta.out_point * self._stretch_factor

    @out_point.setter
    def out_point(self, value: float) -> None:
        validate_number(value)
        self._set_raw_out_point(value)

    @property
    def frame_in_point(self) -> int:
        """The "in" point of the layer, expressed in composition time
        (frames). Read / Write."""
        return round(self.in_point * self.containing_comp.frame_rate)

    @frame_in_point.setter
    def frame_in_point(self, value: int) -> None:
        validate_int(value)
        self.in_point = value / self.containing_comp.frame_rate

    @property
    def frame_out_point(self) -> int:
        """The "out" point of the layer, expressed in composition time
        (frames). Read / Write."""
        return round(self.out_point * self.containing_comp.frame_rate)

    @frame_out_point.setter
    def frame_out_point(self, value: int) -> None:
        validate_int(value)
        self.out_point = value / self.containing_comp.frame_rate

    @property
    def frame_start_time(self) -> int:
        """The start time of the layer, expressed in composition time
        (frames). Read / Write."""
        return round(self.start_time * self.containing_comp.frame_rate)

    @frame_start_time.setter
    def frame_start_time(self, value: int) -> None:
        validate_int(value)
        self.start_time = value / self.containing_comp.frame_rate

    @property
    def index(self) -> int:
        """The 0-based index position of the layer in its containing comp.

        Warning:
            Unlike ExtendScript (1-based), this uses Python's 0-based
            convention so that `comp.layers[layer.index]` works directly.
        """
        return self.containing_comp.layers.index(self)

    @property
    def has_video(self) -> bool:
        """`True` if the layer has a video switch in the Timeline panel.

        Always `False` for [CameraLayer][] and [LightLayer][] objects.
        """
        return False

    @property
    def adjustment_layer(self) -> bool:
        """`True` if the layer is an adjustment layer.

        Always `False` for [CameraLayer][] and [LightLayer][] objects.
        Overridden in [AVLayer][] to read from the binary chunk.
        """
        return False

    @property
    def environment_layer(self) -> bool:
        """`True` if the layer is an environment layer.

        Always `False` for [CameraLayer][] and [LightLayer][] objects.
        Overridden in [AVLayer][] to read from the binary chunk.
        """
        return False

    @property
    def active(self) -> bool:
        """
        When `True`, the layer is active at the current time.

        Overrides [PropertyBase.active][] to evaluate
        [active_at_time][] at [time][].
        """
        return self.active_at_time(self.time)

    @property
    def marker(self) -> Property | None:
        """The layer's marker property.

        A [Property][py_aep.models.properties.property.Property] with
        `match_name="ADBE Marker"` whose keyframes hold marker values.
        `None` when the layer has no markers.
        """
        try:
            prop = self["ADBE Marker"]
        except KeyError:
            return None
        return cast("Property", prop)

    @property
    def markers(self) -> list[MarkerValue]:
        """A flat list of [MarkerValue][] objects for this layer.

        Shortcut for accessing marker data without navigating the property
        tree. Returns an empty list when the layer has no markers.

        Example:
            ```python
            for marker in layer.markers:
                print(marker.comment)
            ```
        """
        if self.marker is None:
            return []
        return cast(
            "list[MarkerValue]",
            [kf.value for kf in self.marker.keyframes],
        )

    def remove_all_markers(self) -> None:
        """Remove all markers from this layer.

        A no-op when the layer has no markers.
        """
        if self.marker is not None:
            self.marker.remove_all_keys()

    @property
    def transform(self) -> PropertyGroup:
        """
        Contains a layer's transform properties.

        This is the Transform `PropertyGroup` (match name
        `ADBE Transform Group`). Individual transform properties (Position,
        Scale, Rotation, etc.) are accessible via
        [properties][PropertyGroup.properties].
        """
        group = self["ADBE Transform Group"]
        assert isinstance(group, PropertyGroup)
        return group

    @property
    def effects(self) -> PropertyGroup | None:
        """
        Contains a layer's effects.

        This is the Effects `PropertyGroup` (match name `ADBE Effect Parade`).
        Each child in [properties][PropertyGroup.properties] is itself a
        [PropertyGroup][] representing one effect.

        Like ExtendScript's `layer.property("Effects")`, the group is
        returned even when it is empty, so the first effect can be added
        with `layer.effects.add_property(...)`. An empty group is falsy,
        so `if layer.effects:` still means "has effects".

        `None` on [CameraLayer][] and [LightLayer][], the only layer kinds
        AE gives no Effects group; every other layer kind always has one.
        """
        return self._optional_group("ADBE Effect Parade")

    @property
    def masks(self) -> PropertyGroup | None:
        """
        Contains a layer's masks.

        This is the Masks `PropertyGroup` (match name `ADBE Mask Parade`).
        Each child in [properties][PropertyGroup.properties] is itself a
        [PropertyGroup][] representing one mask.

        Like [effects][], the group is returned even when it is empty (an
        empty group is falsy), and is `None` only on [CameraLayer][] and
        [LightLayer][], which AE gives no Masks group.
        """
        return self._optional_group("ADBE Mask Parade")

    @property
    def text(self) -> PropertyGroup | None:
        """
        Contains a layer's text properties.

        This is the Text `PropertyGroup` (match name `ADBE Text Properties`),
        holding Source Text, Path Options, More Options and the Animators.

        `None` on every layer that is not a [TextLayer][]: unlike
        [effects][] and [masks][], this group is never synthesized for
        other layer kinds because AE does not expose it on them.
        """
        return self._optional_group("ADBE Text Properties")

    def _optional_group(self, match_name: str) -> PropertyGroup | None:
        """The child `PropertyGroup` for `match_name`, or `None` when this
        layer kind does not have it.

        Missing top-level groups are synthesized per layer kind by
        `synthesize_layer_properties`, so a `None` here means the kind has
        no such group at all, not that the `.aep` merely omitted an empty
        one (AE writes the Effect / Mask Parade only once it has content)."""
        try:
            group = self[match_name]
        except KeyError:
            return None
        return group if isinstance(group, PropertyGroup) else None

    def _leaves_out_live_defaults(self) -> bool:
        """Whether the file leaves out one of `_LIVE_DEFAULTS`, read from the
        chunks so that the tree stays unbuilt when none is."""
        assert self._tdgp is not None
        groups = get_chunks_by_match_name(self._tdgp)
        for group_name, match_name in self._LIVE_DEFAULTS:
            group = filter_by_list_type(
                chunks=groups.get(group_name, []), list_type="tdgp"
            )
            if not group or match_name not in get_chunks_by_match_name(group[0]):
                return True
        return False

    def _write_out_moved_defaults(self) -> None:
        """Write the left-out properties whose default has moved.

        AE leaves a property at its default out of the file, and some
        defaults follow other state (a camera's Position its Zoom, a camera
        or light's its comp's size). When that state changes AE writes the
        property, keeping it where it was, so it reads modified; left out,
        it would reopen at the new default instead (measured on AE 2026).
        Run on save, so every way of changing the state is covered.
        """
        if self._tree_param_defs is not None:
            # Never built, so nothing moved (`CompItem._build_live_defaults`).
            return
        for group_name, match_name in self._LIVE_DEFAULTS:
            group = cast("PropertyGroup", self[group_name])
            prop = cast("Property", group[match_name])
            if prop._tdsb is None or not prop._tdsb.synthetic:
                continue
            if prop.is_modified:
                prop._ensure_materialized()

    def _validate_parent(self, new_parent: Layer | None) -> None:
        """Reject parent assignments ExtendScript refuses: a layer from
        another comp, the layer itself, or any of its own descendants
        (which would create a parenting cycle)."""
        if new_parent is None:
            return
        if not isinstance(new_parent, Layer):
            raise ValueError("parent must be a Layer or None")
        if new_parent.containing_comp is not self.containing_comp:
            raise ValueError("parent must be a layer in the same composition")
        # Walk up from the candidate; hitting self means a cycle. The
        # visited set keeps this terminating even on a file that already
        # contains a parenting cycle.
        seen = {id(self)}
        current: Layer | None = new_parent
        while current is not None:
            if id(current) in seen:
                raise ValueError(
                    "cannot parent a layer to itself or to one of its descendants"
                )
            seen.add(id(current))
            current = current.parent

    @property
    def parent(self) -> Layer | None:
        """The parent of this layer; can be `None`.

        Offset values are calculated to counterbalance any transforms above this layer
        in the hierarchy, so that when you set the parent there is no apparent jump in
        the layer's transform.

        For example, if the new parent has a rotation of 30 degrees, the child layer is
        assigned a rotation of -30 degrees.

        Like After Effects, the offsets are computed from the transforms at the
        composition's current [time][Layer.time], and a parent scaled to 0 is
        set without any offset.

        To set the parent without changing the child layer's transform values, use the
        set_parent_with_jump method.

        Read / Write."""
        if self._parent_id == 0:
            return None
        return self.containing_comp.layers_by_id.get(self._parent_id)

    @parent.setter
    def parent(self, value: Layer | None) -> None:
        self._validate_parent(value)
        old_parent = self.parent
        if old_parent is value:
            return

        # AE compensates once, from the transforms at the comp's current
        # time (measured on AE 2026: with the playhead at 1 s, a child of a
        # parent animated from 0 to 90 degrees gets Rotate Z -45).
        time = self.containing_comp.time
        # A 2D child cannot store an out-of-plane rotation, and AE does not
        # try: it compensates as though every ancestor were 2D. Building the
        # matrices the same way keeps our answer on AE's.
        is_3d = self.is_3d
        comp = self.containing_comp
        self._compensate_reparent(
            value,
            build_world_matrix(self, time, flatten_2d=not is_3d),
            _parent_world(old_parent, time, is_3d),
            _parent_world(value, time, is_3d),
            time,
            (comp.pixel_aspect, position_space_aspect(old_parent, comp)),
            (comp.pixel_aspect, position_space_aspect(value, comp)),
        )

    def _compensate_reparent(
        self,
        new_parent: Layer | None,
        child_world: Mat4,
        old_parent_world: Mat4,
        new_parent_world: Mat4,
        time: float,
        old_aspects: tuple[float, float],
        new_aspects: tuple[float, float],
    ) -> None:
        """Parent this layer to `new_parent` (`None` to unparent), rewriting
        its transform so `child_world` (its world matrix under the old
        parent, at comp `time`) does not move.

        `old_aspects` / `new_aspects` are the `(comp, Position space)` pixel
        aspects under the old / new parent (see
        `resolvers.transform.position_space_aspect`): the transform values
        live in square pixels, so the matrices are squared before they are
        decomposed."""
        try:
            new_parent_inverse = new_parent_world.inverse()
        except ValueError:
            # A parent scaled to 0 has no inverse; AE 2026 parents to it
            # anyway and leaves the child's values untouched.
            self._parent_id = new_parent.id if new_parent is not None else 0
            return
        self._parent_id = new_parent.id if new_parent is not None else 0
        is_3d = self.is_3d
        new_space = new_aspects[1]
        own_aspect = layer_source_aspect(self)
        # The local matrix is `T(pos) . Sp^-1 . R . S . Sl . T(-anchor)`
        # (`build_local_matrix`); undo the two aspect scalings to decompose
        # the square-pixel `T(Sp pos) . R . S . T(-Sl anchor)`.
        new_local = (
            aspect_scale(new_space)
            @ new_parent_inverse
            @ child_world
            @ aspect_scale(1.0 / own_aspect)
        )
        # Maps a point from the old parent's space into the new one; used by
        # both keyframed-Position branches below.
        parent_remap = new_parent_inverse @ old_parent_world

        transform = self.transform

        def current(match_name: str) -> Any:
            prop = cast("Property", transform[match_name])
            return prop.value_at_time(time) if prop.keyframes else prop.value

        # Decompose into AE transform components, keeping anchor fixed.
        anchor = cast("list[float]", current("ADBE Anchor Point"))
        square_anchor = [anchor[0] * own_aspect] + list(anchor[1:])

        # Position and scale come straight from the local matrix - neither
        # depends on how the rotation is split between Orientation and
        # Rotate X/Y/Z. `new_rz` is only used on the 2D path below, where the
        # orientation is divided out of the 3x3 first so it cannot leak into
        # the rotation (a layer switched from 3D to 2D can still carry one).
        orientation = cast("list[float]", current("ADBE Orientation"))
        new_pos = decompose_transform(new_local, square_anchor)[0]
        new_pos = [new_pos[0] / new_space] + list(new_pos[1:])
        _, new_scale, new_rz, _, _ = decompose_transform(
            strip_orientation(new_local, orientation), square_anchor
        )
        if new_scale[0] < 0 and is_3d:
            # `decompose_transform` signals a mirrored basis by negating x
            # alone. AE spreads the flip across all three axes and keeps the
            # rotation proper: a parent scaled [-100, 100, 100] leaves the
            # child at [-100, -100, -100] with Orientation [180, 0, 0]. A 2D
            # layer has no Orientation to absorb that and keeps the x-only
            # flip (AE 2026: a [-100, 100] child under a 150 % parent gets
            # [-66.7, 66.7, 100]).
            new_scale = [-abs(component) for component in new_scale]

        def write_compensation(match_name: str, new_value: Any) -> None:
            # Only write values that actually changed to avoid materializing
            # synthetic properties unnecessarily. Keyframed scale / rotation
            # values are left untouched, matching ExtendScript (the layer
            # may visually jump for those).
            prop = cast("Property", transform[match_name])
            if prop.keyframes:
                return
            if prop.value != new_value:
                prop.value = new_value

        def remap_separated_keyframes(
            leader: Property, followers: list[Property]
        ) -> None:
            """Remap an animated separated Position into the new parent's space.

            A separated leader holds no keyframes of its own, so the generic
            keyframe branch below never sees this case. Each follower
            keyframe is remapped through the leader's composed position at
            its own time, because the transform mixes the axes.
            """
            remap = parent_remap
            # Collected first, applied after: every sample has to see the
            # pre-remap followers, and a component write would move them.
            updates: list[tuple[Keyframe, float]] = []
            remapped: dict[float, list[float]] = {}
            for dimension, follower in enumerate(followers):
                for keyframe in follower.keyframes:
                    time = keyframe.time
                    point = remapped.get(time)
                    if point is None:
                        point = remapped[time] = remap.transform_point(
                            cast("list[float]", leader.value_at_time(time))
                        )
                    updates.append((keyframe, point[dimension]))
            for keyframe, component in updates:
                keyframe.value = component

        # AE remaps a keyframed Scale rather than leaving it: under a parent
        # scaled to 50% each key doubles, and under one scaled
        # [200, 50, 100] each key is divided per axis. Skipping them left
        # the layer 25 px out at one time and 62 px at another.
        scale_prop = cast("Property", transform["ADBE Scale"])
        if scale_prop.keyframes:
            scale_now = cast("list[float]", current("ADBE Scale"))
            factors = [
                new_scale[axis] / scale_now[axis]
                if axis < len(scale_now) and scale_now[axis]
                else 1.0
                for axis in range(len(new_scale))
            ]
            # Skipped when the parent applies no scale, for the reason
            # `write_compensation` gives: an unchanged value is not written.
            if any(factor != 1.0 for factor in factors):
                for keyframe in scale_prop.keyframes:
                    components = cast("list[float]", keyframe.value)
                    keyframe.value = [
                        component * factors[axis] if axis < len(factors) else component
                        for axis, component in enumerate(components)
                    ]
        else:
            write_compensation("ADBE Scale", new_scale)

        # ExtendScript remaps every POSITION keyframe into the new parent's
        # space (measured in AE 2026).
        pos = cast("Property", transform["ADBE Position"])
        separated = pos._separation_followers()
        if separated is not None:
            # AE refuses `setValue` on a separated leader, but compensates
            # the followers itself on a reparent (measured on AE 2026: a
            # separated child at (150, 160) under a parent at (300, 40)
            # becomes X = -150, Y = 120), so go through them directly.
            if any(follower.keyframes for follower in separated):
                remap_separated_keyframes(pos, separated)
            else:
                pos._set_separated_value(new_pos, separated)
        elif pos.keyframes:
            remap = parent_remap
            for kf in pos.keyframes:
                kf_value = cast("list[float]", kf.value)
                dims = len(kf_value)
                kf.value = remap.transform_point(kf_value)[:dims]
                for tangent_attr in ("in_spatial_tangent", "out_spatial_tangent"):
                    tangent = getattr(kf, tangent_attr)
                    if tangent:
                        setattr(
                            kf,
                            tangent_attr,
                            remap.transform_vector(tangent)[: len(tangent)],
                        )
        else:
            write_compensation("ADBE Position", new_pos)

        if self._ldta.layer_type in (LayerType.CAMERA, LayerType.LIGHT):
            # A camera or light keeps its point of interest in the Anchor
            # Point slot, in its parent's space: AE 2026 remaps it like
            # Position (a two-node camera's POI [900, 500, 0] under a null at
            # [700, 400, -100] turned 30 degrees about Y became
            # [123.2, 100, 186.6]).
            poi = cast("Property", transform["ADBE Anchor Point"])
            if poi.keyframes:
                for kf in poi.keyframes:
                    kf_value = cast("list[float]", kf.value)
                    kf.value = parent_remap.transform_point(kf_value)[: len(kf_value)]
            else:
                remapped = parent_remap.transform_point(anchor)[: len(anchor)]
                if remapped != anchor:
                    poi.value = remapped
            if rig_aims_at_poi(self):
                # The look-at toward the remapped POI already turns the rig;
                # AE leaves its Orientation alone.
                return

        if self.auto_orient == AutoOrientType.ALONG_PATH:
            # The path, remapped with Position, carries the parent's turn;
            # AE 2026 leaves the rotations alone (a 2D layer's Rotate Z and
            # a 3D layer's Orientation, animated path or static).
            return
        rotation_delta = rotation_part(
            square_pixels(new_parent_world, *new_aspects)
        ).inverse() @ rotation_part(square_pixels(old_parent_world, *old_aspects))
        if not is_3d:
            # A 2D layer has no Orientation to use, so AE puts the rotation
            # into Rotate Z (measured: a 2D child under a 30-degree parent
            # gets rotZ = -30 and orientation stays [0,0,0]).
            rotation = cast("Property", transform["ADBE Rotate Z"])
            if rotation.keyframes:
                # AE offsets every rotation keyframe rather than giving up on
                # an animated one - keys of 15 and 75 under a 30-degree
                # parent became -15 and 45. Skipping them, as
                # `write_compensation` does, left the layer 35 px out.
                # As a signed turn, not the 0-360 form `compose_orientation`
                # returns: AE stores -15 and 45, not 345 and 405.
                offset = (
                    compose_orientation([0.0, 0.0, 0.0], rotation_delta)[2] + 180.0
                ) % 360.0 - 180.0
                for keyframe in rotation.keyframes:
                    keyframe.value = cast("float", keyframe.value) + offset
                return
            write_compensation("ADBE Rotate Z", new_rz)
            return

        # A 3D layer is compensated entirely through Orientation:
        # `O_new = parent_rotation^-1 . O_old`, with Rotate X/Y/Z left
        # exactly as they were. Verified on AE 2026 over ten cases.
        #
        # This is not just a different way to store the same result. Writing
        # the rotations instead collides with `write_compensation` skipping
        # keyframed properties: a child with a keyframed Rotate Z would get
        # its position compensated but not its rotation, and jump by 362 px
        # in a case where AE does not move it at all.
        orientation_prop = cast("Property", transform["ADBE Orientation"])
        if orientation_prop.keyframes:
            for keyframe in orientation_prop.keyframes:
                keyframe.value = compose_orientation(
                    cast("list[float]", keyframe.value), rotation_delta
                )
            return
        rotated = compose_orientation(orientation, rotation_delta)
        if orientation_prop.value != rotated:
            orientation_prop.value = rotated

    def set_parent_with_jump(self, new_parent: Layer | None) -> None:
        """Sets the parent of this layer to the specified layer, without changing the
        transform values of the child layer.

        There may be an apparent jump in the rotation, translation, or scale of the
        child layer, as this layer's transform values are combined with those of its
        ancestors.

        If you do not want the child layer to jump, set the parent attribute directly.
        In this case, an offset is calculated and set in the child layer's transform
        fields, to prevent the jump from occurring.

        Args:
            new_parent: The new parent layer, or `None` to unparent.

        Raises:
            ValueError: If `new_parent` is this layer itself, one of its
                descendants, or a layer in another composition.
        """
        self._validate_parent(new_parent)
        self._parent_id = new_parent.id if new_parent is not None else 0

    def active_at_time(self, time: float) -> bool:
        """Return whether the layer is active at the given time.

        For this method to return `True`, three conditions must be met:

        1. The layer must be `enabled`.
        2. No other layer in the [containing_comp][] may be soloed unless
           this layer is also [solo][].
        3. `time` must fall between [in_point][] (inclusive) and
           [out_point][] (exclusive).

        Args:
            time: The time in seconds.
        """
        validate_number(time)
        if not self.enabled:
            return False

        any_solo = bool(self.containing_comp.solo_layers)
        if any_solo and not self.solo:
            return False

        if time < self.in_point or time >= self.out_point:
            return False

        return True

    def _layer_relative(self, value: float) -> float:
        """Layer time of a composition time written to the in or out point.

        AE first snaps the time to the layer's tick grid, a tie rounding up
        (measured on AE 2026: 2.5 / 24576 s becomes 3 / 24576 s on a 24 fps
        layer, 1 / 36864 s stays put at 150 %).
        """
        timebase = self._layer_timebase()
        snapped = math.floor(value * timebase + 0.5) / timebase
        return (snapped - self._time_origin) / self._stretch_factor

    def _set_raw_in_point(self, value: float) -> None:
        """Write a new in_point (comp time) to the binary chunk."""
        self._ldta.in_point = self._layer_relative(value)

    def _set_raw_out_point(self, value: float) -> None:
        """Write a new out_point (comp time) to the binary chunk."""
        self._ldta.out_point = self._layer_relative(value)

    # ------------------------------------------------------------------
    # Structural mutations
    # ------------------------------------------------------------------

    def remove(self) -> None:
        """Deletes this layer from the composition.

        Layers that reference this layer as a parent become unparented
        (their transforms are recalculated to preserve world-space
        appearance).  AVLayers that use this layer as a track matte
        lose their matte reference.
        """
        from .av_layer import _unregister_source_usage  # noqa: PLC0415

        comp = self.containing_comp
        removed_id = self.id

        # Unparent children - triggers transform recalculation via the
        # parent setter so the child doesn't visually jump.
        for layer in comp.layers:
            if layer is not self and layer._parent_id == removed_id:
                layer.parent = None

        # Clean track matte refs on AV layers
        for layer in comp.av_layers:
            if layer is not self:
                ldta = layer._ldta
                if (
                    hasattr(ldta, "matte_layer_id")
                    and ldta.matte_layer_id == removed_id
                ):
                    ldta.matte_layer_id = 0

        # Update source _used_in if this layer references a source item
        comp._project._ensure_used_in_linked()
        source = self._source_item
        if source is not None and hasattr(source, "_used_in"):
            _unregister_source_usage(source, comp, exclude=self)  # type: ignore[arg-type]

        # Remove chunk block from comp's chunk list
        start, end = comp._layer_block_slice(self)
        removed = comp._item_list.chunks[start:end]
        del comp._item_list.chunks[start:end]
        rehome_effect_definitions(comp._project, _effect_instances(removed))

        # Remove from model list and rebuild caches
        comp._layers.remove(self)
        comp._invalidate_layer_cache()

    def duplicate(self) -> Layer:
        """Create a duplicate of this layer in the same composition.

        The duplicate is placed directly above (before) the original
        layer.

        Returns:
            The newly created [Layer][].
        """
        return self._clone_into(self.containing_comp, duplicate=True)

    def copy_to_comp(self, into_comp: CompItem) -> Layer:
        """Copy this layer into a composition, as After Effects'
        `copyToComp()` does.

        The copy is placed at the top of the target layer stack. Its parent
        is cleared and its transform rewritten so it keeps its place (the
        parent's transform at time 0 is baked in, whatever the playhead),
        and the layers its effects reference are cleared - also when the
        target is this layer's own [containing_comp][] (use [duplicate][]
        to keep them). Into another composition the track matte and an
        environment light's source are cleared too, and keyframe and
        marker times are kept in seconds whatever the target's frame rate
        (measured on AE 2026).

        Args:
            into_comp: The target [CompItem][].
        Returns:
            The newly created [Layer][] in the target composition.
        """
        # Circular: models.items.composition -> models.layers -> layer
        from ..items.composition import CompItem  # noqa: PLC0415

        if not isinstance(into_comp, CompItem):
            raise ValueError("Target composition must be a CompItem.")
        return self._clone_into(into_comp, duplicate=False)

    def _clone_into(self, into_comp: CompItem, *, duplicate: bool) -> Layer:
        """Clone this layer's chunks into `into_comp` and parse the copy:
        a [duplicate][] (directly above, references kept) or a
        [copy_to_comp][] (on top, references cleared)."""
        # Circular: parsers.layer -> models.layers.av_layer -> layer
        from ...parsers.layer import parse_layer  # noqa: PLC0415

        same_comp = into_comp is self.containing_comp
        # Names before the copy joins the comp: it only clashes with others.
        existing = {lyr.name for lyr in into_comp.layers}
        old_timebase = self._layer_timebase()
        # The copy keeps its place without its parent: AE bakes the parent's
        # transform at time 0 into it, whatever the playhead (measured on
        # AE 2026: a child at [960, 540] under a parent at [100, 100] with
        # anchor [100, 50] lands at [960, 590]; with the playhead at 0.5 s,
        # an animated parent is still taken at 0).
        unparent = None
        if not duplicate and self.parent is not None:
            is_3d = self.is_3d
            src_comp = self.containing_comp
            unparent = (
                build_world_matrix(self, 0.0, flatten_2d=not is_3d),
                _parent_world(self.parent, 0.0, is_3d),
                (src_comp.pixel_aspect, position_space_aspect(self.parent, src_comp)),
            )

        # Clone the full layer block (LIST:Layr + trailing view chunks)
        src_start, src_end = self.containing_comp._layer_block_slice(self)
        src_block = self.containing_comp._item_list.chunks[src_start:src_end]
        cloned_block = [clone_chunk_tree(c) for c in src_block]
        cloned_list = cast("ListChunk", cloned_block[0])

        # Patch layer ID
        cloned_ldta = cast(
            "LdtaChunk",
            find_by_type(
                chunks=cloned_list.chunks,
                chunk_type="ldta",
            ),
        )
        # Layer IDs are unique project-wide, not per-comp.
        cloned_ldta.layer_id = into_comp._project._allocate_id()
        # AE points every effect's hidden -0000 param tdpi at the owning
        # layer; retarget the clones at the fresh id (layer-reference
        # tdpi values keep pointing at the originally referenced layer).
        rewrite_owner_tdpi(cloned_list, cloned_ldta.layer_id)

        # Determine chunk insertion point
        if duplicate:
            model_idx = into_comp._layers.index(self)
            chunk_idx = src_start
        else:
            # AE's copyToComp clears the parent and the effect layer
            # references even within the same comp; the matte (a pre-AE 23
            # record has no matte field and must stay that size) and an
            # environment light's source only when they would point into
            # another comp.
            cloned_ldta.parent_id = 0
            if not same_comp:
                if cloned_ldta.matte_layer_id is not None:
                    cloned_ldta.matte_layer_id = 0
                if cloned_ldta.layer_type == LayerType.LIGHT:
                    cloned_ldta.source_id = _no_source_id(into_comp)
            # A LAYER parameter (Set Matte, Layer Control, CC Sphere's light
            # layer, ...) names a layer of the SOURCE comp; left as-is the
            # destination comp cannot resolve it and AE refuses the whole file
            # ("Can't find layer ID=N in composition X"). AE 2026 writes 0 -
            # "no layer" - into the copy's parameter.
            remap_layer_ref_tdpi(cloned_list, {})
            # tdb4 carries the comp the property was written in; AE restamps
            # the copy to the destination comp (measured: copyToComp from a
            # 25 fps comp into a 24 fps one writes 24576, not 25600). The
            # layer's own stretch scales it, exactly as `_layer_timebase`
            # derives it - a 200 % layer counts ticks against twice the
            # comp's base.
            rewrite_time_base(
                cloned_list, self._layer_timebase(into_comp._cdta.internal_timebase)
            )
            model_idx = 0
            if into_comp.layers:
                chunk_idx = index_by_identity(
                    into_comp._item_list.chunks, into_comp.layers[0]._layer_list
                )
            else:
                chunk_idx = into_comp._find_first_layer_position()
        into_comp._item_list.chunks[chunk_idx:chunk_idx] = cloned_block

        # Re-parse cloned chunks into a model instance
        effect_defs = into_comp._project._effect_param_defs
        new_layer = parse_layer(cloned_list, into_comp, effect_defs)

        into_comp._layers.insert(model_idx, new_layer)

        if not same_comp:
            self._carry_comp_relative_transform(new_layer)
            # Keyframe ticks count against the layer's timebase; keep every
            # key (markers included) at the same second, as AE does (a key
            # at 1 s copied from 25 to 24 fps stays at 1 s).
            new_layer._retime_to_layer_timebase(
                old_timebase, new_layer._layer_timebase()
            )
        if unparent is not None:
            # Unparented as in the source comp: the copy carries those values
            # whatever the target's pixel aspect (AE 2026 keeps Scale 100
            # copying into a 2:1 comp).
            child_world, parent_world, old_aspects = unparent
            source_aspect = old_aspects[0]
            new_layer._compensate_reparent(
                None,
                child_world,
                parent_world,
                Mat4.identity(),
                0.0,
                old_aspects,
                (source_aspect, source_aspect),
            )

        # Increment user-defined name
        if new_layer.is_name_set and new_layer.name in existing:
            new_layer.name = auto_name(new_layer.name, existing)

        into_comp._invalidate_layer_cache()

        # Register source _used_in for the cloned layer
        into_comp._project._ensure_used_in_linked()
        new_source = new_layer._source_item
        if new_source is not None and hasattr(new_source, "_used_in"):
            new_source._used_in.add(into_comp)

        return new_layer

    #: Transform properties whose synthesized default is derived from the
    #: containing composition, so a copy into a different-sized comp would
    #: silently re-centre unless the value is carried over.
    _COMP_RELATIVE_TRANSFORM: tuple[str, ...] = (
        "ADBE Anchor Point",
        "ADBE Position",
        "ADBE Position_0",
        "ADBE Position_1",
    )

    def _carry_comp_relative_transform(self, copy: Layer) -> None:
        """Keep `copy`'s comp-relative transform equal to this layer's.

        A transform property AE never wrote is synthesized from the comp's
        size, so a copy into a different-sized composition would land on the
        new comp's centre instead of where the original sits. AE 2026 keeps
        the absolute value and materializes the chunk to hold it (measured: a
        400x300 solid at position 400,300 copied into a 200x100 comp still
        reads 400,300, with `ADBE Position` now a real cdat).
        """
        src_transform = self.transform
        dst_transform = copy.transform
        if src_transform is None or dst_transform is None:
            return
        for match_name in self._COMP_RELATIVE_TRANSFORM:
            try:
                src_prop = src_transform.property(match_name)
                dst_prop = dst_transform.property(match_name)
            except (KeyError, ValueError):
                continue
            if not isinstance(src_prop, Property) or not isinstance(dst_prop, Property):
                continue
            # An animated property carries real chunks that the clone copied
            # verbatim, so there is nothing to carry over.
            if src_prop.keyframes or dst_prop.keyframes:
                continue
            value = src_prop.value
            if value is None or value == dst_prop.value:
                continue
            dst_prop.value = value

    def move_after(self, layer: Layer) -> None:
        """Moves this layer to a position immediately after (below)
        the specified layer.

        Args:
            layer: The target layer in the same composition.
        """
        if not isinstance(layer, Layer):
            raise ValueError("Target must be a Layer.")

        comp = self.containing_comp
        if layer.containing_comp is not comp:
            raise ValueError("Target layer must be in the same composition.")
        self_idx = comp._layers.index(self)
        target_idx = comp._layers.index(layer)
        # After self is removed, target shifts left by 1 if self was before it
        effective = target_idx - (1 if self_idx < target_idx else 0)
        self._move_to(effective + 1)

    def move_before(self, layer: Layer) -> None:
        """Moves this layer to a position immediately before (above)
        the specified layer.

        Args:
            layer: The target layer in the same composition.
        """
        if not isinstance(layer, Layer):
            raise ValueError("Target must be a Layer.")

        comp = self.containing_comp
        if layer.containing_comp is not comp:
            raise ValueError("Target layer must be in the same composition.")
        self_idx = comp._layers.index(self)
        target_idx = comp._layers.index(layer)
        effective = target_idx - (1 if self_idx < target_idx else 0)
        self._move_to(effective)

    def move_to_beginning(self) -> None:
        """Moves this layer to the topmost position of the composition."""
        self._move_to(0)

    def move_to_end(self) -> None:
        """Moves this layer to the bottommost position of the composition."""
        self._move_to(len(self.containing_comp.layers))

    def _move_to(self, target_index: int) -> None:
        """Move this layer to the given model-list index.

        Uses direct chunk slice extraction and reinsertion, never
        `remove()`, so parent and track matte connections on other
        layers are preserved.
        """
        comp = self.containing_comp

        # Extract and remove chunk block
        start, end = comp._layer_block_slice(self)
        block = comp._item_list.chunks[start:end]
        del comp._item_list.chunks[start:end]

        comp._layers.remove(self)

        # Clamp target index
        target_index = min(target_index, len(comp._layers))

        # Find chunk insertion point
        if target_index < len(comp._layers):
            chunk_idx = index_by_identity(
                comp._item_list.chunks, comp._layers[target_index]._layer_list
            )
        elif comp._layers:
            _, last_end = comp._layer_block_slice(comp._layers[-1])
            chunk_idx = last_end
        else:
            chunk_idx = comp._find_first_layer_position()

        # Insert block and model entry
        comp._item_list.chunks[chunk_idx:chunk_idx] = block
        comp._layers.insert(target_index, self)

        comp._invalidate_layer_cache()
